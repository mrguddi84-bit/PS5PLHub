# PS5PLHub für Android 16

Android-App mit der PS5PLHub-Oberfläche. IP, Dienste, Sprache und Theme bleiben lokal auf dem Gerät. Dienst-Links werden im Browser geöffnet.

## APK bauen

Im GitHub-Repository **Actions → Build Android APK → Run workflow** wählen. Nach dem erfolgreichen Lauf unter **Artifacts** `PS5PLHub-Android16-debug` herunterladen und die APK auf dem Android-Gerät installieren. Android kann beim ersten Installieren eine Freigabe für Apps aus dieser Quelle verlangen.

Die APK aus GitHub Actions ist eine Debug-Version zum privaten Testen. Der Build richtet sich an Android 16 (API 36), mindestens Android 6.0 (API 23).
